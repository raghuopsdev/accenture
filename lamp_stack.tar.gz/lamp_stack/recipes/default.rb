#
# Cookbook:: lamp_stack
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.
